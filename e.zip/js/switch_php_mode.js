// WARNING: 遗弃的js代码和解决方案 以下代码已经废弃
Truephpvar local_dir="php/"
var internet_dir="Truephp/"
var local=["php/register.php","php"]
var internet=[]
